/**
 * 
 */
/**
 * @author pb003515
 *
 */
module JavaHelloWorld {
}